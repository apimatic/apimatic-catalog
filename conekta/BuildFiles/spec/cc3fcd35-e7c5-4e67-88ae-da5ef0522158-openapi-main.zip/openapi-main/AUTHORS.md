title: Authors

Primary Authors
===============

* __[Franklin Carrero](https://github.com/fcarrero)__

    @fcarrero is the current maintainer of the code and has written much of the
    current code base, including a complete refactor of the core for version 2.0.
    He started out by authoring many of the available extensions and later was
    asked to join Yuri, where he began fixing numerous bugs, adding
    documentation and making general improvements to the existing code base.

* __[Jorge Alberto Alonso](https://github.com/jalonsoDevConekta)__

    @jalonsoDevConekta is the current maintainer of the code and has written much of the
    current code base, including a complete refactor of the core for version 2.0.
    He started out by authoring many of the available extensions and later was
    asked to join Yuri, where he began fixing numerous bugs, adding
    documentation and making general improvements to the existing code base.
    
* __[Ezequiel Rozen](https://github.com/ezerozen)__

    @ezerozen is the current maintainer of the code and has written much of the
    current code base, including a complete refactor of the core for version 2.0.
    He started out by authoring many of the available extensions and later was
    asked to join Yuri, where he began fixing numerous bugs, adding
    documentation and making general improvements to the existing code base.

<h1>
  install openapi generator
</h1>


```node
  npm install @openapitools/openapi-generator-cli -g
```

<h2>
How to use
</h2>

<h3>
go generator proyect

</h3>

```
make go
```

<h2>
From many files to one
<h3>

1. Run the command to merge all the files into one:
```node
make merge
```

![distribution](split.png?raw=true "distribution")

## dotnet target framwework
```xml
"targetFramework" : "netstandard2.0;net6.0"
```